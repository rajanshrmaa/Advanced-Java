package com.example.repository;

import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.example.entity.Employee;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class EmployeeRepository {

    @PersistenceContext
    private EntityManager entityManager;

    public List<Employee> findAll() {
        return entityManager.createNamedQuery("Employee.findAll", Employee.class).getResultList();
    }

    public List<Employee> findByDepartment(String department) {
        return entityManager.createNamedQuery("Employee.findByDepartment", Employee.class)
                .setParameter("dept", department)
                .getResultList();
    }
}
