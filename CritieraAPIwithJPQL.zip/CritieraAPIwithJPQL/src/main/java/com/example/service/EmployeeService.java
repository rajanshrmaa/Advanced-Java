package com.example.service;

import com.example.entity.Employee;
import com.example.repository.EmployeeRepositoryJPQL;
import com.example.repository.EmployeeRepositoryCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepositoryJPQL employeeRepositoryJPQL;

    @Autowired
    private EmployeeRepositoryCriteria employeeRepositoryCriteria;

    public List<Employee> getAllEmployeesJPQL() {
        return employeeRepositoryJPQL.findAll();
    }

    public List<Employee> getEmployeesByDepartmentJPQL(String department) {
        return employeeRepositoryJPQL.findByDepartment(department);
    }

    public List<Employee> getAllEmployeesCriteria() {
        return employeeRepositoryCriteria.findAll();
    }

    public List<Employee> getEmployeesByDepartmentCriteria(String department) {
        return employeeRepositoryCriteria.findByDepartment(department);
    }
}
