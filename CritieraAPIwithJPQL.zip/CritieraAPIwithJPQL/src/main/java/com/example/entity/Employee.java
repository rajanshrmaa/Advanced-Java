package com.example.entity;

public class Employee {

}
