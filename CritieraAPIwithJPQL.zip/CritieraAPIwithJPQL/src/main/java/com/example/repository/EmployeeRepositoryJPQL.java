package com.example.repository;

import com.example.entity.Employee;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class EmployeeRepositoryJPQL {

    @PersistenceContext
    private EntityManager entityManager;

    public List<Employee> findAll() {
        return entityManager.createQuery("SELECT e FROM Employee e", Employee.class).getResultList();
    }

    public List<Employee> findByDepartment(String department) {
        return entityManager.createQuery("SELECT e FROM Employee e WHERE e.department = :dept", Employee.class)
                .setParameter("dept", department)
                .getResultList();
    }
}
