package com.example.service;

import com.example.entity.Employee;
import com.example.repository.EmployeeRepository;
import javax.transaction.Transactional;
import java.util.List;

public class EmployeeService {

    private EmployeeRepository employeeRepository;

    @Transactional
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Transactional
    public List<Employee> getEmployeesByDepartment(String department) {
        return employeeRepository.findByDepartment(department);
    }
}
