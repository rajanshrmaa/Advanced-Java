package com.example.repository;

import com.example.entity.Employee;
import javax.persistence.*;
import java.util.List;

public class EmployeeRepository {

    @PersistenceContext
    private EntityManager entityManager;

    public List<Employee> findAll() {
        return entityManager.createNamedQuery("Employee.findAll", Employee.class).getResultList();
    }

    public List<Employee> findByDepartment(String department) {
        return entityManager.createNamedQuery("Employee.findByDepartment", Employee.class)
                .setParameter("dept", department)
                .getResultList();
    }
}
