package com.mphasis.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import jakarta.annotation.Generated;

@Entity
public class Book {

    @Id
    @Generated(value = { "" })
    private Long id;
    private String bookTitle;
    private String bookPublisher;
    private int year;

    // Getters and setters
    public Long getid() {
        return id;
    }

    public void setid(Long id) {
        this.id = id;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookPublisher() {
        return bookPublisher;
    }

    public void setBookPublisher(String bookPublisher) {
        this.bookPublisher = bookPublisher;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}