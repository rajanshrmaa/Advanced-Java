
package com.mphasis.service;

import com.mphasis.Entity.Book;
import com.mphasis.repository.BookStoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookstoreService {

    private final BookStoreRepository bookStoreRepository;

    @Autowired
    public BookstoreService(BookStoreRepository bookStoreRepository) {
        this.bookStoreRepository = bookStoreRepository;
    }

    // Add or update a book
    public Book saveBook(Book book) {
        return bookStoreRepository.save(book);
    }

    // Update book details (can use saveAndFlush or save)
    public Book updateBook(Book book) {
        return bookStoreRepository.saveAndFlush(book);
    }

    // Get all books
    public List<Book> findAllBooks() {
        return bookStoreRepository.findAll();
    }

    // Find a book by its ID
    public Optional<Book> findByBookID(Long bookId) {
        return bookStoreRepository.findById(bookId);
    }

    // Find books by title
    public List<Book> findByBookTitle(String title) {
        return bookStoreRepository.findByBookTitle(title);
    }

    // Find books by publisher using a 'like' query
    public List<Book> findByBookPublisherLike(String publisherPattern) {
        return bookStoreRepository.findByBookPublisherLike(publisherPattern);
    }

    // Find books by publication year
    public List<Book> findByYear(int year) {
        return bookStoreRepository.findByYear(year);
    }
}
