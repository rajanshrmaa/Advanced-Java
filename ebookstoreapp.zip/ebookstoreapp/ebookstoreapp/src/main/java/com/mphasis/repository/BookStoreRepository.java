

package com.mphasis.repository;

import com.mphasis.Entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookStoreRepository extends JpaRepository<Book, Long> {

    // Add or save a book (inherited from JpaRepository)
    Book save(Book book);

    // Update book details (inherited from JpaRepository)
    Book saveAndFlush(Book book);

    // Find all books
    List<Book> findAll();

    // Find a book by its ID
    Optional<Book> findById(Long bookId);

    // Find books by title
    List<Book> findByBookTitle(String title);

    // Find books by publisher using a 'like' query
    List<Book> findByBookPublisherLike(String publisherPattern);

    // Find books by publication year
    List<Book> findByYear(int year);

	boolean existsById(int getid);
}