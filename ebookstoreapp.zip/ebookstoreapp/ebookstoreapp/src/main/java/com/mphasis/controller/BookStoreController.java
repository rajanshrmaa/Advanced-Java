package com.mphasis.controller;

import com.mphasis.Entity.Book;
import com.mphasis.repository.BookStoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/books")
public class BookStoreController {

    @Autowired
    private BookStoreRepository bookStoreRepository;

    // Add a new book
    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        Book savedBook = bookStoreRepository.save(book);
        return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
    }

    // Update book details
    @PutMapping
    public ResponseEntity<Book> updateBook(@RequestBody Book book) {
        if (!bookStoreRepository.existsById(book.getid())) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        Book updatedBook = bookStoreRepository.saveAndFlush(book);
        return new ResponseEntity<>(updatedBook, HttpStatus.OK);
    }

    // Get all books
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookStoreRepository.findAll();
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    // Get a book by ID
    @GetMapping("/{book_id}")
    public ResponseEntity<Book> getBookById(@PathVariable("book_id") Long bookId) {
        Optional<Book> book = bookStoreRepository.findById(bookId);
        return book.map(ResponseEntity::ok).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Delete a book by ID
    @DeleteMapping("/{book_id}")
    public ResponseEntity<Void> deleteBookById(@PathVariable("book_id") Long bookId) {
        if (!bookStoreRepository.existsById(bookId)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        bookStoreRepository.deleteById(bookId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // Get books by title
    @GetMapping("/title/{book_title}")
    public ResponseEntity<List<Book>> getBooksByTitle(@PathVariable("book_title") String bookTitle) {
        List<Book> books = bookStoreRepository.findByBookTitle(bookTitle);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    // Get books by publisher
    @GetMapping("/publisher/{book_publisher}")
    public ResponseEntity<List<Book>> getBooksByPublisher(@PathVariable("book_publisher") String bookPublisher) {
        List<Book> books = bookStoreRepository.findByBookPublisherLike("%" + bookPublisher + "%");
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    // Get books by year
    @GetMapping
    public ResponseEntity<List<Book>> getBooksByYear(@RequestParam("year") int year) {
        List<Book> books = bookStoreRepository.findByYear(year);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
}