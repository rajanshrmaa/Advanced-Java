package com.bank.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;


@Entity
public class Login {

    @Id
    private long accountNumber;    // Primary key
    private String accountHolderName;
    private String password;       // This is the password field

    // Default constructor (JPA requirement)
    public Login() {}

    // Constructor for convenience
    public Login(long accountNumber, String accountHolderName, String password) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.password = password;
    }

    // Getter and Setter for accountNumber
    public long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    // Getter and Setter for accountHolderName
    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    // Getter and Setter for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
