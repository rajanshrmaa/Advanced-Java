package com.bank.controller;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.ui.Model;

import com.bank.entity.Login;
import com.bank.repository.LoginRepository;
import com.bank.service.BankService;

@Controller
public class BankController {

    @Autowired
    private LoginRepository loginRepository;

    @Autowired
    private BankService bankService;

    // Show login page
    @GetMapping("/")
    public String showLoginForm() {
        return "login";
    }

    // Login validation
    @PostMapping("/login")
    public String login(@RequestParam long accountNumber, @RequestParam String accountHolderName,
                        @RequestParam String password, Model model) {
        Optional<Login> loginOpt = loginRepository.findByAccountNumberAndAccountHolderName(accountNumber, accountHolderName);
        if (loginOpt.isPresent() && loginOpt.get().getPassword().equals(password)) {
            model.addAttribute("accountNumber", accountNumber);
            return "dashboard";
        }
        model.addAttribute("error", "Invalid login credentials!");
        return "login";
    }

    // Show balance
    @GetMapping("/checkBalance/{accountNumber}")
    public String checkBalance(@PathVariable long accountNumber, Model model) {
        String message = bankService.checkBalance(accountNumber);
        model.addAttribute("message", message);
        return "dashboard";
    }

    // Debit amount
    @PostMapping("/debit")
    public String debitAmount(@RequestParam long accountNumber, @RequestParam BigDecimal amount, Model model) {
        String message = bankService.debitAmount(accountNumber, amount);
        model.addAttribute("message", message);
        return "dashboard";
    }

    // Credit amount
    @PostMapping("/credit")
    public String creditAmount(@RequestParam long accountNumber, @RequestParam BigDecimal amount, Model model) {
        String message = bankService.creditAmount(accountNumber, amount);
        model.addAttribute("message", message);
        return "dashboard";
    }
}
